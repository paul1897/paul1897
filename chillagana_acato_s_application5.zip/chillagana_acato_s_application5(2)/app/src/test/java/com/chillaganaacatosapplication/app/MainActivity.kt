package com.chillaganaacatosapplication.app

import com.chillaganaacatosapplication.app.appcomponents.base.BaseActivity
import com.chillaganaacatosapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}