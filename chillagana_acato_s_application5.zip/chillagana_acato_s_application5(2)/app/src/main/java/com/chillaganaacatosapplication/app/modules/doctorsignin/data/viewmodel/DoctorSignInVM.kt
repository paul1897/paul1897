package com.chillaganaacatosapplication.app.modules.doctorsignin.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.chillaganaacatosapplication.app.modules.doctorsignin.`data`.model.DoctorSignInModel
import org.koin.core.KoinComponent

class DoctorSignInVM : ViewModel(), KoinComponent {
  val doctorSignInModel: MutableLiveData<DoctorSignInModel> = MutableLiveData(DoctorSignInModel())

  var navArguments: Bundle? = null
}
