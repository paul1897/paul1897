package com.chillaganaacatosapplication.app.modules.doctorsignin.`data`.model

import com.chillaganaacatosapplication.app.R
import com.chillaganaacatosapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DoctorSignInModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_11_31_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOneHundred: String? = MyApp.getInstance().resources.getString(R.string.lbl_100)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLoremipsum: String? = MyApp.getInstance().resources.getString(R.string.lbl_lorem_ipsum)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_35_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSetratadepro: String? =
      MyApp.getInstance().resources.getString(R.string.msg_se_trata_de_pro)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGetStartedBtn: String? = MyApp.getInstance().resources.getString(R.string.lbl_buy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNotienesunac: String? =
      MyApp.getInstance().resources.getString(R.string.msg_no_tienes_una_c)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRegistrate: String? = MyApp.getInstance().resources.getString(R.string.lbl_registrate)

)
