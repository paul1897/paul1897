package com.chillaganaacatosapplication.app.modules.doctorsignin.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.chillaganaacatosapplication.app.R
import com.chillaganaacatosapplication.app.appcomponents.base.BaseActivity
import com.chillaganaacatosapplication.app.databinding.ActivityDoctorSignInBinding
import com.chillaganaacatosapplication.app.modules.doctorsignin.data.viewmodel.DoctorSignInVM

class DoctorSignInActivity :
    BaseActivity<ActivityDoctorSignInBinding>(R.layout.activity_doctor_sign_in) {
  private val viewModel: DoctorSignInVM by viewModels<DoctorSignInVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.doctorSignInVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }
  override fun onResume() {
    super.onResume()
    // La actividad ha vuelto a primer plano y ha obtenido el enfoque
  }
  override fun onPause() {
    super.onPause()
    // Otra actividad está tomando el foco (esta actividad está a punto de pausarse)
  }

  override fun onStop() {
    super.onStop()
    // La actividad ya no es visible para el usuario (está "detenida")
  }

  override fun onDestroy() {
    super.onDestroy()
    // La actividad está a punto de ser destruida
  }
  companion object {
    const val TAG: String = "DOCTOR_SIGN_IN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, DoctorSignInActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
