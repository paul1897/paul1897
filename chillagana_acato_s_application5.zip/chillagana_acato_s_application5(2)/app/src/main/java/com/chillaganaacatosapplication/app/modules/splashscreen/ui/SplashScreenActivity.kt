package com.chillaganaacatosapplication.app.modules.splashscreen.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.chillaganaacatosapplication.app.R
import com.chillaganaacatosapplication.app.appcomponents.base.BaseActivity
import com.chillaganaacatosapplication.app.databinding.ActivitySplashScreenBinding
import com.chillaganaacatosapplication.app.modules.doctorsignin.ui.DoctorSignInActivity
import com.chillaganaacatosapplication.app.modules.splashscreen.data.viewmodel.SplashScreenVM

class SplashScreenActivity :
    BaseActivity<ActivitySplashScreenBinding>(R.layout.activity_splash_screen) {
  private val viewModel: SplashScreenVM by viewModels<SplashScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.splashScreenVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = DoctorSignInActivity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
    
    }

    override fun setUpClicks(): Unit {
    }
  override fun onStart() {
    super.onStart()
    // La actividad se está volviendo visible para el usuario
  }

  override fun onResume() {
    super.onResume()
    // La actividad ha vuelto a primer plano y ha obtenido el enfoque
  }

  override fun onPause() {
    super.onPause()
    // Otra actividad está tomando el foco (esta actividad está a punto de pausarse)
  }

  override fun onStop() {
    super.onStop()
    // La actividad ya no es visible para el usuario (está "detenida")
  }


  override fun onDestroy() {
    super.onDestroy()
    // La actividad está a punto de ser destruida
  }

    companion object {
      const val TAG: String = "SPLASH_SCREEN_ACTIVITY"

    }
  }
