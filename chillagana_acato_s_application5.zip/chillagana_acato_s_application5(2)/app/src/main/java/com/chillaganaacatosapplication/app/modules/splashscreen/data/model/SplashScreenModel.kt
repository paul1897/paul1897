package com.chillaganaacatosapplication.app.modules.splashscreen.`data`.model

import com.chillaganaacatosapplication.app.R
import com.chillaganaacatosapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SplashScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_11_31_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSHOPPINGAPP: String? = MyApp.getInstance().resources.getString(R.string.lbl_shopping_app)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOneHundred: String? = MyApp.getInstance().resources.getString(R.string.lbl_100)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempstiusdo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_lorem_pstius_do)

)
